
from pyhanlp import *
import re


class NerByHanlp:
    def __init__(self, data_path, result_path):
        self.tags = ['product_name', 'company_name', 'person_name', 'location', 'org_name', 'time']
        self.data_path = data_path
        self.result_path = result_path

    def nerHanlp(self):
        NER = HanLP.newSegment().enablePlaceRecognize(True).enableNameRecognize(True).enableOrganizationRecognize(True)
        pattern = re.compile(r'(/[A-Za-z0-9]+)')

        rfile = open(self.data_path, encoding='UTF-8')

        data = rfile.readlines()

        for s in data:
            p = NER.seg(s)
            for i in p:
                word, tag = pattern.split(str(i))[:-1]
                self.result_write(word, tag)

        rfile.close()

    def result_write(self, word, tag):
        wfile = open(self.result_path, 'a', encoding='UTF-8')

        if tag == '/nr' or tag == '/nr1' or tag == '/nrj' or tag == '/nr2' or tag == '/nrf':
            word = '{{person_name:' + word + '}}'
        elif tag == '/ns' or tag == '/nsf':
            word = '{{location:' + word + '}}'
        elif tag == '/nt' or tag == '/ni' or tag == '/nic' or tag == '/nis' or tag == '/nit':
            word = '{{org_name:' + word + '}}'

        wfile.write(word)

        wfile.close()


if __name__ == '__main__':
    nbr = NerByHanlp('data0.txt',
                     'result_hanlp.txt')

    nbr.nerHanlp()
